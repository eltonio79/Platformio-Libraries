./arduinoOTA -address 192.168.88.34 -port 65280 -username arduino -password password -sketch hello.bin -b -upload /sketch
