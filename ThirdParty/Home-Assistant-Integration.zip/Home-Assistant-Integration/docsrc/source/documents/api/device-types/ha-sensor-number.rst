HASensorNumber class
====================

.. doxygenclass:: HASensorNumber
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: