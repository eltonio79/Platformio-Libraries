Device types API
================

.. toctree::

    ha-base-device-type
    ha-binary-sensor
    ha-button
    ha-camera
    ha-cover
    ha-device-tracker
    ha-device-trigger
    ha-fan
    ha-hvac
    ha-light
    ha-lock
    ha-number
    ha-scene
    ha-select
    ha-sensor
    ha-sensor-number
    ha-switch
    ha-tag-scanner
