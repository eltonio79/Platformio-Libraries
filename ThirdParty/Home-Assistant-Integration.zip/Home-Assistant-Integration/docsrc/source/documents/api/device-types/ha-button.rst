HAButton class
==============

.. doxygenclass:: HAButton
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: