HADeviceTrigger class
=====================

.. doxygenclass:: HADeviceTrigger
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: