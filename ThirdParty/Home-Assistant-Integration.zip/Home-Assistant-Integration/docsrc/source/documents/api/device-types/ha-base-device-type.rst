HABaseDeviceType class
======================

.. doxygenclass:: HABaseDeviceType
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: