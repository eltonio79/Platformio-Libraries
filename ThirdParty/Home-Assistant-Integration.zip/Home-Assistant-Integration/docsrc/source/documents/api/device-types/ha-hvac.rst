HAHVAC class
============

.. doxygenclass:: HAHVAC
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: