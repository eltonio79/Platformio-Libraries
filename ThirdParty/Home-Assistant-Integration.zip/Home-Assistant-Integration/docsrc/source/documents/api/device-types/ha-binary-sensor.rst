HABinarySensor class
====================

.. doxygenclass:: HABinarySensor
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: