HACamera class
==============

.. doxygenclass:: HACamera
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: