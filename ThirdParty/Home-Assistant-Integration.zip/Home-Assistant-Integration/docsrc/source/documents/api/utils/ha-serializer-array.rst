HASerializerArray class
=======================

.. doxygenclass:: HASerializerArray
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: