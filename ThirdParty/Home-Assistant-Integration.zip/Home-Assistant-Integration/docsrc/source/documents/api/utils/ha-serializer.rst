HASerializer class
==================

.. doxygenclass:: HASerializer
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: