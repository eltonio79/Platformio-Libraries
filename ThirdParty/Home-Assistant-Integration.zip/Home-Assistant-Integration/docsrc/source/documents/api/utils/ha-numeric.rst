HANumeric class
===============

.. doxygenclass:: HANumeric
   :project: ArduinoHA
   :members:
   :protected-members:
   :private-members:
   :undoc-members: