
Getting started
===============

Welcome to the ArduinoHA library!
This documentation is a step-by-step guide that presents all features of the library.
If you feel that there is anything unclear don't hesitate to open a new GitHub discussion.

Have fun!

.. toctree::
    :maxdepth: 2

    prerequisites
    installation
    compatible-hardware
    examples